<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<link rel="stylesheet" type="text/css" href="https://cl-rp.com/foro/Themes/NightBreeze20/css/index.css?fin20" />
	<link rel="stylesheet" type="text/css" href="https://cl-rp.com/foro/Themes/NightBreeze20/css/responsive.css?fin20" />
	<link href="https://use.fontawesome.com/releases/v5.11.2/css/all.css" crossorigin="anonymous" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="https://cl-rp.com/foro/Themes/NightBreeze20/css/tooltipster.bundle.min.css" />
	<link rel="stylesheet" type="text/css" href="https://cl-rp.com/foro/Themes/NightBreeze20/css/tooltipster-sideTip-borderless.min.css" />
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
	<script>
		jq = jQuery.noConflict(true);
	</script>
	<script type="text/javascript" src="https://cl-rp.com/foro/Themes/NightBreeze20/scripts/tooltipster.bundle.min.js"></script>
	
	<link rel="stylesheet" type="text/css" href="https://cl-rp.com/foro/Themes/NightBreeze20/css/notwebkit.css" />
	<script type="text/javascript" src="https://cl-rp.com/foro/Themes/default/scripts/script.js?fin20"></script>
	<script type="text/javascript" src="https://cl-rp.com/foro/Themes/NightBreeze20/scripts/theme.js?fin20"></script>
	<script type="text/javascript"><!-- // --><![CDATA[
		var smf_theme_url = "https://cl-rp.com/foro/Themes/NightBreeze20";
		var smf_default_theme_url = "https://cl-rp.com/foro/Themes/default";
		var smf_images_url = "https://cl-rp.com/foro/Themes/NightBreeze20/images";
		var smf_scripturl = "https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;";
		var smf_iso_case_folding = false;
		var smf_charset = "UTF-8";
		var ajax_notification_text = "Cargando...";
		var ajax_notification_cancel_text = "Cancelar";
	// ]]></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="theme-color" content="#181818">
	<meta name="msapplication-navbutton-color" content="#181818">
	<meta name="apple-mobile-web-app-status-bar-style" content="#181818">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="description" content="Ciudad Latina RP - Índice" />
	<meta name="keywords" content="roleplay, samp, gta multiplayer, servidor rp" />
	<title>Ciudad Latina RP - Índice</title>
	<link rel="canonical" href="https://cl-rp.com/foro/index.php" />
	<link rel="help" href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=help" />
	<link rel="search" href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=search" />
	<link rel="contents" href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;" />
	<link rel="alternate" type="application/rss+xml" title="Ciudad Latina RP - RSS" href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;type=rss;action=.xml" /><script src="https://www.google.com/recaptcha/api.js"></script>
	<link rel="stylesheet" type="text/css" id="recaptcha_css" href="https://cl-rp.com/foro/Themes/default/css/recaptcha.css" />
	<link rel="stylesheet" type="text/css" href="https://cl-rp.com/foro/Themes/default/css/BBCode-YouTube2.css" />
		<link rel="stylesheet" type="text/css" href="https://cl-rp.com/foro/Themes/default/css/jquery.qtip.css" />
		<link rel="stylesheet" type="text/css" href="https://cl-rp.com/foro/Themes/default/css/user_info.css" />
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8/jquery.min.js"></script>
		<script type="text/javascript" src="https://cl-rp.com/foro/Themes/default/scripts/jquery.qtip.min.js"></script>

		<script type="text/javascript">
		var ui = jQuery.noConflict();
		ui(document).ready(function()
		{

			var loading = 'Cargando...'; //The script don't work if this is empty..
			var uic_style = 'qtip-blue';

			ui('a.user_info[rel]').each(function()
			{
				var username = this.id.replace('ui_','');
				// We make use of the .each() loop to gain access to each element via the "this" keyword...
				ui(this).qtip(
				{
					content: {
						// Set the text to an image HTML string with the correct src URL to the loading image you want to use

						text: loading,
						ajax: {
							url: ui(this).attr('rel'), // Use the rel attribute of each element for the url to load
							type: 'POST',
							
							data: 'user='+username
						},
						title: {
							text: ui(this).text(), // Give the tooltip a title using each elements text
							button: true
						}
					},
					position: {
						at: 'bottom center', // Position the tooltip above the link
						my: 'top center',
						viewport: ui(window), // Keep the tooltip on-screen at all times
						effect: false // Disable positioning animation
					},
					show: {
						event: 'click',
						solo: true // Only show one tooltip at a time
					},
					hide: 'unfocus',
					style: {
						classes: uic_style+' qtip-rounded'
					}
				})
			})

			// Make sure it doesn't follow the link when we click it
			.click(function(event) { event.preventDefault(); });
		});
		</script>
	<script>
        jq(document).ready(function() {
            jq('.tooltip').tooltipster({
				delay: 0,
				theme: 'tooltipster-borderless'
			});
        });
    </script>
</head>
<body>
	<header><div class="frame">
		<div id="top_section" class="wideOpen">
			<div class="wrapper">
				<div class="user guest">
					<ul class="dropmenu">
			<li><a href="javascript:void(0)" class="firstlevel loginOpen"><i class="fas fa-sign-in-alt"></i>    <span>Ingresar</span></a></li>
			<li><a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=register" class="firstlevel "><i class="fas fa-user-plus"></i>    <span>Registrarse</span></a></li>		</ul>
				</div>
		<nav>
			<div class="incarn taphoOnly"><h4>Menu</h4><div class="menuOpener taphoOnlyInline floatright buttonLike" data-state="opened"><i class="fas fa-times"></i></div></div>
			<ul class="dropmenu" id="menu_nav">
				<li id="button_home">
					<a class="active firstlevel" href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;">
						<i class="fas fa-home"></i>
						<span class="last firstlevel">Inicio</span>
						
					</a>
				</li>
				<li id="button_help">
					<a class="firstlevel" href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=help">
						<i class="fas fa-info"></i>
						<span class="firstlevel">Ayuda</span>
						
					</a>
				</li>
			</ul>
		</nav><div class="menuOpener taphoOnlyInline floatright buttonLike" data-state="closed"><i class="fas fa-bars"></i></div>
			</div>
		</div>
		<div id="upper_section" class="middletext wrapper">
			<h1 class="forumtitle" >
				<a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;" class="">
				<div>Ciudad Latina RP<br><span></span></div></a>
			</h1>

		</div>	<div class="clear"></div>
		</div>
		<div class="clear"></div>
	</header><div class="header_back"></div>
	<main>
	<div class="navigate_section">
		<div class="searchButton fsOpen buttonLike icon_style floatright tooltip" title="Buscar"><i class="fas fa-search"></i></div>
		
		<div class="home-tree"><a href="https://cl-rp.com/foro"><i class="fas fa-home"></i></a></div>
		<ul>
			<li  class="last"><div class="cust">
				<a  href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;"><span>Ciudad Latina RP</span></a>
			</div></li>
		</ul>
	</div>
		<div class="frame">
			<div id="main_content_section">
			<div class="taphoOnly">
				<div class="cat_bar">
					<h3 class="catbg">
						<i class="fas fa-newspaper"></i>    Noticias
					</h3>
				</div>
				<div class="windowbg2">
					<span class="topslice"><span></span></span>
					<div class="content">
						SMF - Just Installed!
					</div>
					<span class="botslice"><span></span></span>
				</div>
			</div>
	<div id="boardindex_table">
		<table class="table_list">
			<tbody class="header" id="category_17">
				<tr>
					<td colspan="4">
						<div class="cat_bar">
							<h3 class="catbg">
								<a class="tooltip" title="Mensajes no leídos" href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=unread;c=17">Importante: Registro en el Foro</a>
							</h3>
						</div>
					</td>
				</tr>
			</tbody>
			<tbody class="content" id="category_17_boards">
				<tr id="board_472" class="windowbg2 redirect">
					<td class="icon ">
						<a href="https://cl-rp.com/foro/index.php/board,472.0.html?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e">
							<img src="https://cl-rp.com/foro/Themes/NightBreeze20/images/redirect.png" alt="*" title="*" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://cl-rp.com/foro/index.php/board,472.0.html?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e" name="b472">Leer antes de Registrarse</a>

						<p class="bdcrp">¿Nuevo en la Comunidad? Lee está información importante antes de llevar a cabo el registro, para así asegurar un registro exitoso.</p>
					</td>
					<td class="stats">
						<span class="buttonLike invert notButton"><span>11335</span><i class="fas fa-share-square"></i>   Redirecciones</span>
					</td>
					<td class="lastpost">
					</td>
				</tr>
			</tbody>
			<tbody class="divider">
				<tr>
					<td colspan="4"></td>
				</tr>
			</tbody>
			<tbody class="header" id="category_1">
				<tr>
					<td colspan="4">
						<div class="cat_bar">
							<h3 class="catbg">
								<a class="tooltip" title="Mensajes no leídos" href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=unread;c=1">Ciudad Latina RP - IP: samp.cl-rp.com:7777</a>
							</h3>
						</div>
					</td>
				</tr>
			</tbody>
			<tbody class="content" id="category_1_boards">
				<tr id="board_318" class="windowbg2 redirect">
					<td class="icon ">
						<a href="https://cl-rp.com/foro/index.php/board,318.0.html?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e">
							<img src="https://cl-rp.com/foro/Themes/NightBreeze20/images/redirect.png" alt="*" title="*" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://cl-rp.com/foro/index.php/board,318.0.html?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e" name="b318">Discord</a>

						<p class="bdcrp">¿No estás en el Discord oficial de la comunidad? Ingresa aquí para unirte y comenzar a interactuar con los distintos canales.</p>
					</td>
					<td class="stats">
						<span class="buttonLike invert notButton"><span>14302</span><i class="fas fa-share-square"></i>   Redirecciones</span>
					</td>
					<td class="lastpost">
					</td>
				</tr>
				<tr id="board_42" class="windowbg redirect">
					<td class="icon ">
						<a href="https://cl-rp.com/foro/index.php/board,42.0.html?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e">
							<img src="https://cl-rp.com/foro/Themes/NightBreeze20/images/redirect.png" alt="*" title="*" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://cl-rp.com/foro/index.php/board,42.0.html?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e" name="b42">Reglas</a>

						<p class="bdcrp">Conoce en este apartado todas las reglas vigentes en el servidor</p>
					</td>
					<td class="stats">
						<span class="buttonLike invert notButton"><span>12571</span><i class="fas fa-share-square"></i>   Redirecciones</span>
					</td>
					<td class="lastpost">
					</td>
				</tr>
				<tr id="board_726" class="windowbg2 ">
					<td class="icon ">
						<a href="https://cl-rp.com/foro/index.php/board,726.0.html?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e">
							<img src="https://cl-rp.com/foro/Themes/NightBreeze20/images/off.png" alt="No hay nuevos Mensajes" title="No hay nuevos Mensajes" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://cl-rp.com/foro/index.php/board,726.0.html?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e" name="b726">Información General</a>

						<p class="bdcrp">Conoce los conceptos de rol que se aplican dentro del servidor para poder estar al tanto!</p>
					</td>
					<td class="stats">
						<span class="buttonLike invert notButton"><span>2</span><i class="fas fa-comments"></i>   Mensajes</span><span class="buttonLike invert notButton"><span>2</span><i class="fas fa-file-alt"></i>   Temas</span>
					</td>
					<td class="lastpost">
						<span style="display:block;" class="buttonLike invert notButton"><i class="fas fa-user-edit"></i><strong>Último mensaje</strong>  por <a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=profile;u=1758" style="color: #952BCD;">Orlando_Abagnale</a><br />
						en <a href="https://cl-rp.com/foro/index.php/topic,12472.msg31632.html?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e#new" title="[ - Organigrama del STAFF In Game - ] ">[ - Organigrama del STAF...</a><br />
						on Mayo 09, 2022, 02:00:01 pm
						</span>
					</td>
				</tr>
			</tbody>
			<tbody class="divider">
				<tr>
					<td colspan="4"></td>
				</tr>
			</tbody>
		</table>
	</div>
	<div id="posting_icons" class="flow_hidden">
		<ul class="reset">
			<li class="floatleft"><img src="https://cl-rp.com/foro/Themes/NightBreeze20/images/new_none.png" alt="" /> No hay nuevos Mensajes</li>
			<li class="floatleft"><img src="https://cl-rp.com/foro/Themes/NightBreeze20/images/new_redirect.png" alt="" /> Foro de Redirección</li>
		</ul>
	</div>
	<span class="clear upperframe"><span></span></span>
	<div class="roundframe bi" style="background-color: transparent"><div class="innerframe">
		<div id="upshrinkHeaderIC">
		<div class="boardindex_block users_online" style="width:100%;float:none;">
		<div style="margin:2px">
			<div class="title_barIC">
				<h4 class="titlebg">
					<span class="ie6_header floatleft">
						<i class="fas fa-users"></i>    Usuarios en Línea  <i class="smalltext">(Usuarios activos en los últimos 120 minutos)</i>
					</span>
				</h4>
			</div>
			<p class="inline stats">
				24 Visitantes, 21 Usuarios
			</p><p class="inline smalltext">
				<a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=profile;u=1758" style="color: #952BCD;" style="color: #952BCD;">Orlando_Abagnale</a>, <a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=profile;u=13439">Christian_Rogers</a>, <a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=profile;u=13238">Charls_Black</a>, <a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=profile;u=10755">Axel_Davis</a>, <a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=profile;u=14575">Luke_Gates</a>, <a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=profile;u=11182">Melly_Hanssen</a>, <a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=profile;u=7041">Caterina_Gaitao</a>, <a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=profile;u=1943">Lane_Cortis</a>, <a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=profile;u=6195">Paulo_Paixhao</a>, <a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=profile;u=5997">Erasmo_Marshall</a>, <a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=profile;u=11608">Leonardo_DeRossi</a>, <a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=profile;u=11365">Mané_Carvalho</a>, <a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=profile;u=8843">Thomas_DiAngelo</a>, <a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=profile;u=13306">Alan_Villera</a>, <a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=profile;u=14211">Jowell_Sokolov</a>, <a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=profile;u=14131">Octavio_Hernandezz</a>, <a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=profile;u=14263">Leep_Norris</a>, <a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=profile;u=11266">Lucas_Hogan</a>, <a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=profile;u=12406">Magnus_McTaggart</a>, <a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=profile;u=15057">Gustav_Albarn</a>, <a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=profile;u=14008">Horacio_Vasquez</a></p>
			<span class="buttonLike invert notButton tiny smalltext" style="margin: 0;">
				Máximo Online Hoy: <strong>58</strong>.
				Máximo Online Siempre: 1554 (Octubre 18, 2020, 04:22:38 pm)
			</span>
		</div>
		<div style="margin:2px">
			<div class="title_barIC">
				<h4 class="titlebg">
					<span class="ie6_header floatleft">
						<i class="fas fa-chart-pie"></i>    Estadísticas SMF
					</span>
				</h4>
			</div>

				<ul class="stats_index_items">
					<li><i class="fas fa-file-alt"></i>    <span><b>19101</b> Mensajes en <b>6275</b> Temas por <b>2269</b> Usuarios. </span></li>
					<li><i class="fas fa-user"></i>    <span>Último usuario: <strong> <a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=profile;u=15127">Boris_Vitale</a></strong></span></li>
					<li><i class="fas fa-clock"></i>    <span>Último mensaje: <strong>&quot;<a href="https://cl-rp.com/foro/index.php/topic,12472.msg31632.html?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e#new" title="[ - Organigrama del STAFF In Game - ] ">[ - Organigrama del STAF...</a>&quot;</strong>  ( Mayo 09, 2022, 02:00:01 pm )<br /></span></li>
					<a class="buttonLike invert tiny" href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=recent">Recent Forum Posts</a>
					
				</ul>

			</div></div>
		</div>
	</div></div>
	<span class="lowerframe"><span></span></span>
	<script type="text/javascript"><!-- // --><![CDATA[
		var oInfoCenterToggle = new smc_Toggle({
			bToggleEnabled: true,
			bCurrentlyCollapsed: false,
			aSwappableContainers: [
				'upshrinkHeaderIC'
			],
			aSwapImages: [
				{
					sId: 'upshrink_ic',
					srcExpanded: smf_images_url + '/collapse.gif',
					altExpanded: 'Encoger o expandir encabezado.',
					srcCollapsed: smf_images_url + '/expand.gif',
					altCollapsed: 'Encoger o expandir encabezado.'
				}
			],
			oThemeOptions: {
				bUseThemeSettings: false,
				sOptionName: 'collapse_header_ic',
				sSessionVar: 'a3378b8d',
				sSessionId: '843cc0a0c1ebdb396d99e5c1cff69e7b'
			},
			oCookieOptions: {
				bUseCookie: true,
				sCookieName: 'upshrinkIC'
			}
		});
	// ]]></script>
				<div class="clear"></div>
			</div>

		</div>

		<div class="clear"></div>
	</main>
	<footer>
		<div class="clear"></div>
		<div class="frame">
			<div class="wrapper">
				<div class="righter">
					<ul class="reset">
						<li class="copyright">
			<span class="smalltext" style="display: inline; visibility: visible; font-family: Verdana, Arial, sans-serif;"><a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=credits" title="Simple Machines Forum" target="_blank" class="new_win">SMF 2.0.17</a> | <a href="http://www.simplemachines.org/about/smf/license.php" title="License" target="_blank" class="new_win">SMF &copy; 2019</a>, <a href="http://www.simplemachines.org" title="Simple Machines" target="_blank" class="new_win">Simple Machines</a> | <a style="font-size:10px;" href="http://www.smfsimple.com" title="Todo para tu foro SMF">Mods by SMFSimple.com</a>
			</span></li>
					</ul>
				</div>
				<div class="middler">
					<!--
					--><!--
					--><!--
					-->
			</div>
			<div class="lefter">
				<a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;">Ciudad Latina RP &copy; 2022</a><br><p>Agosto 18, 2022, 12:58:03 am</p>
			</div>
		</div>
		<div class="clear">
	</div>
	</div><div class="clear"></div></footer>
	<div class="goup taphoNone"><i class="fas fa-chevron-up"></i></div><div class="fullscreen searchBar" style="display:none;">
			<div class="fsClose"><i class="fas fa-times-circle"></i></div>
			<div class="fsInner">
				<form id="search_form" action="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=search2" method="post" accept-charset="UTF-8">
					<div class="inGroup" style="margin-top: 25px;">
						<input type="text" name="search" value="" class="input_text" required/>
						<span class="highlight"></span>
						<span class="bar"></span>
						<label>Search </label>
					</div>
					<input type="submit" name="submit" value="Buscar" class="button_submit" />
					<input type="hidden" name="advanced" value="0" /></form>
			</div>
		</div>
		<div class="fullscreen loginBar" style="display:none;">
			<div class="fsClose"><i class="fas fa-times-circle"></i></div>
			<div class="fsInner">
				<script type="text/javascript" src="https://cl-rp.com/foro/Themes/default/scripts/sha1.js"></script>
				<form id="guest_form" action="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=login2" method="post" accept-charset="UTF-8"  onsubmit="hashLoginPassword(this, '843cc0a0c1ebdb396d99e5c1cff69e7b');" autocomplete="off" >
					<input autocomplete="false" name="hidden" type="text" style="display:none;">
					<div class="inGroup griny" style="margin-top: 25px;">
						<input type="text" name="user" size="10" class="input_text" autocomplete="off" required/>
						<span class="highlight"></span>
						<span class="bar"></span>
						<label>Usuario</label>
					</div>
					<div class="inGroup griny">
						<input type="password" name="passwrd" size="10" class="input_password" autocomplete="nope" required/>
						<span class="highlight"></span>
						<span class="bar"></span>
						<label>Contraseña</label>
					</div>
					<label class="container">Recordar siempre Usuario/Contraseña
					  <input type="checkbox" name="cookieneverexp" class="input_check" />
					  <span class="checkmark"></span>
					</label>
					<div class="downer">
						<input type="submit" value="Ingresar" class="button_submit" />
						<a href="https://cl-rp.com/foro/index.php?PHPSESSID=1d071fc4973b9cc3fdb592e19f42f74e&amp;action=reminder">¿Olvidaste tu contraseña?</a>
					</div>
					<input type="hidden" name="hash_passwrd" value="" /><input type="hidden" name="a3378b8d" value="843cc0a0c1ebdb396d99e5c1cff69e7b" />
				</form>
			</div>
		</div>
	<script>
		jq(document).ready(function () {
			jq(".fsOpen").click(function () {
				jq("input:text:visible:first").focus();
				jq("body").css("overflow", "hidden");
			});
			jq(".searchButton").click(function () {
				jq(".fullscreen.searchBar").css("display", "block");
			});
			jq(".loginOpen").click(function () {
				jq(".fullscreen.loginBar").css("display", "block");
			});
			jq(".fullscreen .fsClose").click(function () {
				jq(".fullscreen").css("display", "none");
				jq("body").css("overflow", "auto");
			});
		});
	</script>
	<div class="sampleClass"></div>
</body></html>